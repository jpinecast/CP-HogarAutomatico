import express from 'express';
import { WebSocketServer } from 'ws';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import fs from 'fs';
import { startMonitoring, stopMonitoring, monitorEmitter } from './index_reinicio.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Configuración de logs
const LOG_DIR = path.join(__dirname, 'logs');
const LOG_FILE = path.join(LOG_DIR, `monitor-${new Date().toISOString().split('T')[0]}.log`);

// Crear directorio de logs si no existe
if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR);
}

// Función para escribir en el archivo de log
function writeToLog(message, type = 'INFO') {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] [${type}] ${message}\n`;
    
    fs.appendFile(LOG_FILE, logMessage, (err) => {
        if (err) {
            console.error('Error al escribir en el archivo de log:', err);
        }
    });
}

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Servir archivos estáticos desde la carpeta public
app.use(express.static(path.join(__dirname, 'public')));

// Endpoint para obtener los logs
app.get('/api/logs', (req, res) => {
    const date = req.query.date || new Date().toISOString().split('T')[0];
    const logFile = path.join(LOG_DIR, `monitor-${date}.log`);
    
    if (fs.existsSync(logFile)) {
        fs.readFile(logFile, 'utf8', (err, data) => {
            if (err) {
                res.status(500).json({ error: 'Error al leer el archivo de logs' });
            } else {
                const logs = data.split('\n')
                    .filter(line => line.trim())
                    .map(line => {
                        const [timestamp, type, ...message] = line.split('] ');
                        return {
                            timestamp: timestamp.substring(1),
                            type: type.substring(1),
                            message: message.join('] ').trim()
                        };
                    });
                res.json(logs);
            }
        });
    } else {
        res.json([]);
    }
});

// Variables de estado
let monitorStatus = {
    isRunning: false,
    startTime: null,
    processedEmails: 0,
    lastProcessed: null,
    connectedClients: new Set()
};

// Función para verificar la conexión WebSocket
function heartbeat() {
    this.isAlive = true;
}

// Verificar conexiones activas periódicamente
const interval = setInterval(() => {
    wss.clients.forEach((ws) => {
        if (ws.isAlive === false) {
            monitorStatus.connectedClients.delete(ws);
            return ws.terminate();
        }
        ws.isAlive = false;
        ws.ping();
    });
}, 30000);

wss.on('close', () => {
    clearInterval(interval);
});

// Iniciar el monitor automáticamente al arrancar el servidor
async function initializeMonitor() {
    try {
        await startMonitoring();
        monitorStatus.isRunning = true;
        monitorStatus.startTime = Date.now();
        writeToLog('Monitor iniciado automáticamente', 'INFO');
        broadcastStatus('Monitor iniciado automáticamente');
    } catch (error) {
        console.error('Error al iniciar el monitor:', error);
        monitorStatus.isRunning = false;
        writeToLog(`Error al iniciar el monitor: ${error.message}`, 'ERROR');
        broadcastStatus(`Error al iniciar el monitor: ${error.message}`);
    }
}

// Configurar eventos del monitor
monitorEmitter.on('log', (message) => {
    console.log('[Monitor Log]:', message);
    writeToLog(message, 'INFO');
    broadcastStatus(message);
});

monitorEmitter.on('emailsProcessed', (count) => {
    console.log('[Correos Procesados]:', count);
    writeToLog(`Procesados ${count} correos nuevos`, 'INFO');
    monitorStatus.processedEmails += count;
    broadcastStatus();
});

monitorEmitter.on('lastProcessed', (subject) => {
    console.log('[Último Correo]:', subject);
    writeToLog(`Último correo procesado: ${subject}`, 'INFO');
    monitorStatus.lastProcessed = subject;
    broadcastStatus();
});

// Función para calcular el tiempo de ejecución
function getUptime() {
    if (!monitorStatus.startTime) return '0:00:00';
    const diff = Date.now() - monitorStatus.startTime;
    const hours = Math.floor(diff / 3600000);
    const minutes = Math.floor((diff % 3600000) / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

// Función para enviar actualizaciones a todos los clientes
function broadcastStatus(log = null) {
    const status = {
        isRunning: monitorStatus.isRunning,
        stats: {
            uptime: getUptime(),
            processedEmails: monitorStatus.processedEmails,
            lastProcessed: monitorStatus.lastProcessed,
            activeConnections: monitorStatus.connectedClients.size
        }
    };
    if (log) status.log = log;

    const message = JSON.stringify(status);
    monitorStatus.connectedClients.forEach(client => {
        if (client.readyState === 1) {
            try {
                client.send(message);
            } catch (error) {
                console.error('Error al enviar mensaje al cliente:', error);
                monitorStatus.connectedClients.delete(client);
            }
        }
    });
}

// Actualizar el estado cada segundo
const statusInterval = setInterval(broadcastStatus, 1000);

// Manejar conexiones WebSocket
wss.on('connection', (ws) => {
    ws.isAlive = true;
    ws.on('pong', heartbeat);
    monitorStatus.connectedClients.add(ws);
    
    const clientCount = monitorStatus.connectedClients.size;
    console.log('Nuevo cliente conectado. Total de clientes:', clientCount);
    writeToLog(`Nuevo cliente conectado. Total de clientes: ${clientCount}`, 'INFO');

    // Enviar estado actual al cliente cuando se conecta
    ws.send(JSON.stringify({
        isRunning: monitorStatus.isRunning,
        stats: {
            uptime: getUptime(),
            processedEmails: monitorStatus.processedEmails,
            lastProcessed: monitorStatus.lastProcessed,
            activeConnections: monitorStatus.connectedClients.size
        }
    }));

    ws.on('message', async (message) => {
        try {
            const data = JSON.parse(message);

            switch (data.type) {
                case 'start':
                    if (!monitorStatus.isRunning) {
                        try {
                            await startMonitoring();
                            monitorStatus.isRunning = true;
                            monitorStatus.startTime = Date.now();
                            writeToLog('Monitor iniciado manualmente', 'INFO');
                            broadcastStatus('Monitor iniciado');
                        } catch (error) {
                            monitorStatus.isRunning = false;
                            writeToLog(`Error al iniciar el monitor: ${error.message}`, 'ERROR');
                            broadcastStatus(`Error al iniciar el monitor: ${error.message}`);
                        }
                    }
                    break;

                case 'stop':
                    if (monitorStatus.isRunning) {
                        try {
                            await stopMonitoring();
                            monitorStatus.isRunning = false;
                            monitorStatus.startTime = null;
                            writeToLog('Monitor detenido manualmente', 'INFO');
                            broadcastStatus('Monitor detenido');
                        } catch (error) {
                            writeToLog(`Error al detener el monitor: ${error.message}`, 'ERROR');
                            broadcastStatus(`Error al detener el monitor: ${error.message}`);
                        }
                    }
                    break;

                case 'getStatus':
                    ws.send(JSON.stringify({
                        isRunning: monitorStatus.isRunning,
                        stats: {
                            uptime: getUptime(),
                            processedEmails: monitorStatus.processedEmails,
                            lastProcessed: monitorStatus.lastProcessed,
                            activeConnections: monitorStatus.connectedClients.size
                        }
                    }));
                    break;
            }
        } catch (error) {
            console.error('Error al procesar mensaje del cliente:', error);
            writeToLog(`Error al procesar mensaje del cliente: ${error.message}`, 'ERROR');
        }
    });

    ws.on('close', () => {
        monitorStatus.connectedClients.delete(ws);
        const clientCount = monitorStatus.connectedClients.size;
        console.log('Cliente desconectado. Total de clientes:', clientCount);
        writeToLog(`Cliente desconectado. Total de clientes: ${clientCount}`, 'INFO');
    });

    ws.on('error', (error) => {
        console.error('Error en la conexión WebSocket:', error);
        writeToLog(`Error en la conexión WebSocket: ${error.message}`, 'ERROR');
        monitorStatus.connectedClients.delete(ws);
    });
});

// Manejar señales de terminación
process.on('SIGINT', async () => {
    writeToLog('Recibida señal de terminación. Cerrando servidor...', 'INFO');
    console.log('\nRecibida señal de terminación. Cerrando servidor...');
    clearInterval(statusInterval);
    clearInterval(interval);
    await stopMonitoring();
    process.exit(0);
});

process.on('SIGTERM', async () => {
    writeToLog('Recibida señal de terminación. Cerrando servidor...', 'INFO');
    console.log('\nRecibida señal de terminación. Cerrando servidor...');
    clearInterval(statusInterval);
    clearInterval(interval);
    await stopMonitoring();
    process.exit(0);
});

// Iniciar el servidor y el monitor
const PORT = process.env.PORT || 2323;

server.listen(PORT, () => {
    console.log(`Servidor web ejecutándose en http://localhost:${PORT}`);
    writeToLog(`Servidor web iniciado en puerto ${PORT}`, 'INFO');
    initializeMonitor(); // Iniciar el monitor automáticamente
}); 