import dotenv from "dotenv";
import imap from "imap-simple";
import { simpleParser } from "mailparser";
import fetch from "node-fetch";
import { chromium } from "playwright"; // Cambiado a Playwright
import { EventEmitter } from 'events';

dotenv.config();

// Crear un emisor de eventos para comunicación
export const monitorEmitter = new EventEmitter();

const imapConfig = {
  imap: {
   user: "admin@cuentasapremium.com",
    password: "Pineda97*",
    host: "mail.cuentasapremium.com",
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false },
  },
};

let connection = null;
let isMonitoringActive = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 10;
const BASE_RECONNECT_DELAY = 5000;

export async function startMonitoring() {
  if (isMonitoringActive) return;
  
  try {
    console.log("Conectando al servidor IMAP...");
    monitorEmitter.emit('log', "Conectando al servidor IMAP...");
    
    connection = await imap.connect(imapConfig);
    await connection.openBox("INBOX");
    
    console.log("Conexión establecida y monitoreando correos.");
    monitorEmitter.emit('log', "Conexión establecida y monitoreando correos.");
    
    isMonitoringActive = true;

    connection.on("mail", async () => {
      console.log("Nuevo correo detectado. Procesando...");
      monitorEmitter.emit('log', "Nuevo correo detectado. Procesando...");
      
      const searchCriteria = ["UNSEEN"];
      const fetchOptions = { bodies: ["HEADER", "TEXT"], markSeen: true };

      try {
        console.log("Buscando correos no leídos...");
        const messages = await connection.search(searchCriteria, fetchOptions);
        console.log(`Número de correos encontrados: ${messages.length}`);
        monitorEmitter.emit('log', `Número de correos encontrados: ${messages.length}`);
        monitorEmitter.emit('emailsProcessed', messages.length);

        for (const [index, message] of messages.entries()) {
          console.log(`Procesando correo #${index + 1}`);
          monitorEmitter.emit('log', `Procesando correo #${index + 1}`);

          const headers = message.parts.find(part => part.which === "HEADER");
          const body = message.parts.find(part => part.which === "TEXT");
          if (!headers) {
            console.log("No se encontraron encabezados en el correo. Ignorando.");
            monitorEmitter.emit('log', "No se encontraron encabezados en el correo. Ignorando.");
            continue;
          }

          const parsed = await simpleParser(body.body);
          const subject = headers.body.subject || parsed.subject;

          console.log("Asunto del correo:", subject);
          monitorEmitter.emit('log', `Asunto del correo: ${subject}`);
          monitorEmitter.emit('lastProcessed', subject);

          if (subject && subject.includes("Importante: Cómo actualizar tu Hogar con Netflix")) {
            console.log("Correo relacionado con Netflix detectado.");
            monitorEmitter.emit('log', "Correo relacionado con Netflix detectado.");
            
            const authorizationLink = extractNetflixLink(parsed.html || parsed.text);

            if (authorizationLink) {
              console.log(`Enlace de autorización encontrado: ${authorizationLink}`);
              monitorEmitter.emit('log', "Enlace de autorización encontrado. Procesando...");
              await approveHomeUpdate(authorizationLink);
            } else {
              console.log("No se encontró un enlace de aprobación en el correo.");
              monitorEmitter.emit('log', "No se encontró un enlace de aprobación en el correo.");
            }
          }
        }
      } catch (err) {
        console.error("Error al buscar correos:", err);
        monitorEmitter.emit('log', `Error al buscar correos: ${err.message}`);
      }
    });

    connection.on("error", async (error) => {
      console.error("Error en la conexión IMAP:", error);
      monitorEmitter.emit('log', `Error en la conexión IMAP: ${error.message}`);
      await stopMonitoring();
      reconnect();
    });

    connection.on("end", async () => {
      console.log("Conexión IMAP finalizada. Intentando reconectar...");
      monitorEmitter.emit('log', "Conexión IMAP finalizada. Intentando reconectar...");
      await stopMonitoring();
      reconnect();
    });
  } catch (error) {
    console.error("Error en el monitoreo de correos:", error);
    monitorEmitter.emit('log', `Error en el monitoreo de correos: ${error.message}`);
    await stopMonitoring();
    reconnect();
  }
}

export async function stopMonitoring() {
  if (!isMonitoringActive) return;
  
  try {
    if (connection) {
      await connection.end();
      connection = null;
    }
  } catch (error) {
    console.error("Error al detener el monitor:", error);
    monitorEmitter.emit('log', `Error al detener el monitor: ${error.message}`);
  } finally {
    isMonitoringActive = false;
  }
}

function extractNetflixLink(content) {
  console.log("Extrayendo enlaces del correo...");
  const regex = /https?:\/\/www\.netflix\.com\/[^\s]+/g;
  const links = content.match(regex);

  if (links) {
    const authorizationLink = links.find(link =>
      link.startsWith("https://www.netflix.com/account/update-primary-location?")
    );
    return authorizationLink || null;
  }
  return null;
}

async function approveHomeUpdate(link) {
  console.log("Intentando aprobar la actualización de hogar...");
  try {
    const response = await fetch(link, { method: "GET" });
    if (response.ok) {
      console.log("Se abrió el enlace inicial correctamente.");
    } else {
      console.error("Error al abrir el enlace inicial:", response.statusText);
      return;
    }

    console.log("Navegando para confirmar la actualización...");
    await confirmHomeUpdate(link);
  } catch (error) {
    console.error("Error al realizar la solicitud de aprobación:", error);
  }
}

async function confirmHomeUpdate(link) {
  console.log("Iniciando navegador para confirmar la actualización...");
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();

  try {
    await page.goto(link, { waitUntil: "networkidle" });
    console.log("Página cargada. Verificando contenido...");

    const iframe = await page.frame({ name: "iframe" });
    const frame = iframe || page;

    console.log("Buscando botón de confirmación...");
    const buttonSelector = 'button[data-uia="set-primary-location-action"]';
    await frame.waitForSelector(buttonSelector, { timeout: 60000 });
    console.log("Botón encontrado. Haciendo clic...");
    await frame.click(buttonSelector);

    console.log("Esperando mensaje de confirmación...");
    await page.waitForSelector('div:has-text("Actualizaste tu Hogar con Netflix")', { timeout: 60000 });
    console.log("Confirmación completada.");

    await browser.close();
  } catch (error) {
    console.error("Error al confirmar la actualización:", error);
    await browser.close();
  }
}

async function reconnect() {
  console.log("Reconectando...");
  monitorEmitter.emit('log', "Reconectando...");
  
  reconnectAttempts++;
  const delay = Math.min(BASE_RECONNECT_DELAY * Math.pow(2, reconnectAttempts - 1), 300000);
  
  monitorEmitter.emit('log', `Intento de reconexión ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}`);
  
  if (reconnectAttempts <= MAX_RECONNECT_ATTEMPTS) {
    setTimeout(async () => {
      try {
        await startMonitoring();
        reconnectAttempts = 0;
      } catch (error) {
        console.error("Error en el intento de reconexión:", error);
        monitorEmitter.emit('log', `Error en el intento de reconexión: ${error.message}`);
        reconnect();
      }
    }, delay);
  } else {
    console.error("Se alcanzó el número máximo de intentos de reconexión.");
    monitorEmitter.emit('log', "Se alcanzó el número máximo de intentos de reconexión. Por favor, reinicie manualmente.");
    process.exit(1);
  }
}

startMonitoring();
